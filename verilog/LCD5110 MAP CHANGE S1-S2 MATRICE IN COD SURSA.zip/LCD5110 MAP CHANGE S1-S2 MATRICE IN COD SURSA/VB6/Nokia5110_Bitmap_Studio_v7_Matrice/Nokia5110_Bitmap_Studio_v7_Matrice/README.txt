NOKIA 5110 BITMAP STUDIO v7 - EXPORT MATRICE VERILOG 0/1
=======================================================

PROIECT COMPLET VB6 (v6 este pastrata + exporturi noi)
Deschide Nokia5110_Bitmap_Studio.vbp dintr-un folder extras.
Fisierul modWheel.bas este necesar pentru rotita mouse-ului.
Pastreaza exemplu_implicit.png langa proiect.

Functiile vechi raman: fotografii JPG/PNG/BMP, crop/zoom, dithering,
desen cu mouse-ul, stergere, inversare, Export HEX, Export Verilog
cu octeti inclusi.

FUNCTII NOI
- "Memoreaza imaginea S1": salveaza instantaneul bitmapului 84x48 curent.
- "Memoreaza imaginea S2": salveaza un al doilea bitmap 84x48.
- "Verilog autonom - MATRICE 0/1 (imagine curenta)": un LCD5110.v
  autonom cu o matrice vizibila de 48 randuri x 84 biti.
- "Verilog autonom - MATRICE 0/1 (S1 + S2)": un LCD5110.v
  autonom cu doua imagini (96 randuri x 84 biti), selectabile prin
  butoanele S1 si S2, active LOW. La pornire apare S1.

PAS CU PAS PENTRU DOUA IMAGINI
1. Ajusteaza prima imagine din previzualizare; apasa "Memoreaza imaginea S1".
2. Deschide sau deseneaza a doua imagine; apasa "Memoreaza imaginea S2".
3. Apasa "Verilog autonom - MATRICE 0/1 (S1 + S2)".
4. Salveaza sursa sub numele LCD5110.v si adaug-o in Quartus.
5. Pastreaza asignarile LCD de la montajul care functioneaza deja;
   S1 = PIN_88, S2 = PIN_89 (daca acestea sunt butoanele confirmate).
6. Compileaza; nu este nevoie de .hex la acest export.

FORMATUL IMAGINII IN SURSA
pixeli[y] = 84'b...;  y=0..47 sau 0..95 pentru doua imagini.
Bitul cel mai din stanga = coloana 0; 1 negru, 0 alb.
Hardware-ul grupeaza 8 pixeli verticali intr-un octet PCD8544.

Fisierul EXEMPLU_LCD5110_doua_matrici.v este un exemplu de export
cu cele doua matrice din codul demonstrativ al utilizatorului.

Nota: Verificari statice ale sursei; compilarea VB6 sub Windows si
compilarea Quartus pe placa fizica nu au putut fi executate aici.

----------------------------------------
README ORIGINAL v6
----------------------------------------
Nokia 5110 Bitmap Studio v5 - layout reorganizat
===================================================

Aceasta versiune pastreaza functionalitatea v4. Modificarile sunt
strict la aranjarea obiectelor: antet clar, doua zone de lucru
aliniate, optiuni de conversie sub imagini, editare si export
grupate separat, cu spatii mai mici intre controale.

Deschide Nokia5110_Bitmap_Studio.vbp in Visual Basic 6.
Nu sunt necesare controale OCX externe. Modulul modWheel.bas
ramane indispensabil pentru rotita mouse-ului.

Nokia 5110 Bitmap Studio v4 - Lock & Paint (VB6)

Instalare: extrage toate fisierele intr-un folder simplu, de exemplu C:\VB6\Nokia5110. Deschide Nokia5110_Bitmap_Studio.vbp in Visual Basic 6.

STANGA (fotografia originala)
- Muta mouse-ul: cadrul galben urmareste cursorul.
- CLICK STANGA: fixeaza cadrul (verde), inca un click il elibereaza (galben).
- ROTITA: micsoreaza/mareste cadrul, inclusiv cand este fix.
- CLICK DREAPTA + TRAGERE: deseneaza puncte negre peste fotografia din stanga.
- SHIFT + CLICK DREAPTA + TRAGERE: sterge punctele desenate pe stanga.
- Desenul din stanga ramane ancorat in fotografia originala, nu in ecranul LCD.

DREAPTA (bitmap LCD 84x48)
- CLICK STANGA + TRAGERE: pixel negru.
- CLICK DREAPTA + TRAGERE: sterge pixel (alb).
- ROTITA: modifica pragul alb/negru.
- Dithering se activeaza din checkbox.
- "Sterge retusurile" elimina modificarile pe ambele imagini.

EXPORT: Export HEX produce 504 octeti in format pagina PCD8544. Butonul Sursa Verilog creeaza un modul LCD5110 cu bitmap inclus integral; nu necesita fisier HEX separat.

IMPORTANT VB6: modulul modWheel.bas foloseste subclassing Windows pentru WM_MOUSEWHEEL. Inchide fereastra normal, nu apasa Stop/End din IDE cat timp aplicatia este pornita.

Versiunea este actualizata structural, dar nu a fost compilata cu Visual Basic 6 sub Windows.

VERSIUNEA 6 - EXEMPLU IMPLICIT
------------------------------------
La pornire, incarca automat exemplu_implicit.png in ambele zone.
Pastreaza acest fisier in acelasi director cu .vbp sau .exe.
Fotografia poate fi inlocuita apoi prin butonul Deschide.
