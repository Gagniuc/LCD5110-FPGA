
module LCD5110 (
    input wire clk,
    output reg lcd_rst = 0, lcd_ce = 1,
    output reg lcd_dc = 0, lcd_din = 0, lcd_clk = 0
);

    reg [7:0] img [0:503];
    initial $readmemh("GAGNIUC_84x48.hex", img);

    function [7:0] cmd;
        input [2:0] n;
        begin
            case (n)
                0: cmd=8'h21; 1: cmd=8'hB8;
                2: cmd=8'h04; 3: cmd=8'h14;
                4: cmd=8'h20; 5: cmd=8'h0C;
                6: cmd=8'h80; 7: cmd=8'h40;
            endcase
        end
    endfunction

    reg [21:0] startup = 0;
    reg [6:0] div = 0;
    reg [9:0] index = 0;
    reg [7:0] shift = 0;
    reg [2:0] bit_no = 7;
    reg [1:0] state = 0;
    reg done = 0;

    wire [7:0] data_byte = (index < 8) ?
        cmd(index[2:0]) : img[index - 10'd8];

    always @(posedge clk) begin
        if (startup < 22'd2500000) begin
            startup <= startup + 1'b1;
            if (startup == 22'd1000000) lcd_rst <= 1;
        end
        else if (!done) begin
            if (div == 7'd99) begin
                div <= 0;
                case (state)
                    0: begin
                        lcd_ce <= 0;
                        lcd_dc <= (index >= 8);
                        lcd_din <= data_byte[7];
                        shift <= data_byte;
                        bit_no <= 7;
                        state <= 1;
                    end
                    1: begin lcd_clk <= 1; state <= 2; end
                    2: begin
                        lcd_clk <= 0;
                        if (bit_no == 0) state <= 3;
                        else begin
                            bit_no <= bit_no - 1'b1;
                            lcd_din <= shift[6];
                            shift <= {shift[6:0],1'b0};
                            state <= 1;
                        end
                    end
                    3: begin
                        lcd_ce <= 1;
                        if (index == 511) done <= 1;
                        else index <= index + 1'b1;
                        state <= 0;
                    end
                endcase
            end else div <= div + 1'b1;
        end
    end
endmodule
